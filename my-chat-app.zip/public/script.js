const chatBox = document.getElementById('chat-box');
const input = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const settingsBtn = document.getElementById('settings-btn');
const settingsModal = document.getElementById('settings-modal');
const saveKeyBtn = document.getElementById('save-key-btn');
const closeSettingsBtn = document.getElementById('close-settings-btn');
const apiKeyInput = document.getElementById('api-key-input');

let apiKey = localStorage.getItem('gemimi_api_key') || '';

settingsBtn.onclick = () => settingsModal.classList.remove('hidden');
closeSettingsBtn.onclick = () => settingsModal.classList.add('hidden');

saveKeyBtn.onclick = async () => {
  apiKey = apiKeyInput.value.trim();
  if (!apiKey) return alert('Nhập API key!');
  localStorage.setItem('gemimi_api_key', apiKey);

  try {
    const res = await fetch('/save-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ apiKey })
    });
    const data = await res.json();
    if (data.success) alert('Đã lưu!');
    settingsModal.classList.add('hidden');
  } catch {
    alert('Lưu thất bại!');
  }
};

sendBtn.onclick = sendMessage;
input.addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });

async function sendMessage() {
  const message = input.value.trim();
  if (!message || !apiKey) return;
  appendMessage('Bạn', message);
  input.value = '';

  try {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, apiKey })
    });
    const data = await res.json();
    appendMessage('AI', data.reply);
  } catch {
    appendMessage('AI', 'Lỗi phản hồi!');
  }
}

function appendMessage(sender, text) {
  const div = document.createElement('div');
  div.textContent = `${sender}: ${text}`;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}
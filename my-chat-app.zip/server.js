require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');
const { Pool } = require('pg');

const app = express();
const port = process.env.PORT || 3000;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Lưu API key
app.post('/save-key', async (req, res) => {
  const { apiKey } = req.body;
  if (!apiKey) return res.status(400).json({ error: 'API key missing' });
  try {
    await pool.query(
      `INSERT INTO api_keys (key_value) VALUES ($1)`,
      [apiKey]
    );
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'DB error' });
  }
});

// Gửi chat đến Gemimi
app.post('/chat', async (req, res) => {
  const { message, apiKey } = req.body;
  if (!message || !apiKey) return res.status(400).json({ error: 'Missing data' });

  try {
    const response = await axios.post('https://api.gemimi.ai/v1/chat', {
      prompt: message,
      model: "gemimi-standard"
    }, {
      headers: { 'Authorization': `Bearer ${apiKey}` }
    });

    res.json({ reply: response.data.reply });
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: 'API error' });
  }
});

app.listen(port, () => console.log(`Server running on port ${port}`));